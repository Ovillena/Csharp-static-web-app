﻿using System;
using System.Collections.Generic;

namespace Functions101.Models.Toons
{
    public partial class Student
    {
        public string StudentId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string School { get; set; }
    }
}
